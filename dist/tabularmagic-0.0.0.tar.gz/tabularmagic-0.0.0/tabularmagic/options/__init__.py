from .._src.display.print_options import print_options

__all__ = ["print_options"]
