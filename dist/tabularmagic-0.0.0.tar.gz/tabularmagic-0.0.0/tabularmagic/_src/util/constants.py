# Constant values shared throughout package

TOSTR_MAX_WIDTH = 80
TOSTR_ROUNDING_N_DECIMALS = 3



