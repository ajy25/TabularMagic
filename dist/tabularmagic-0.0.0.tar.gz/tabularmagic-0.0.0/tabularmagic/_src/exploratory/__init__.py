from .eda import EDAReport, StatisticalTestResult


__all__ = ["EDAReport", "StatisticalTestResult"]
