from .rbm import GaussianBernoulliRBM
