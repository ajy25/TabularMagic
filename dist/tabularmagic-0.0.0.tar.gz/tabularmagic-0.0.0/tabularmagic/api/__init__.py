from .._src.tabularmagic import TabularMagic
from .._src.data.datahandler import DataHandler


