from .eda import ComprehensiveEDA
from .regression.voting_selection import RegressionVotingSelectionReport
from .regression.mlreg import MLRegressionReport
from .regression.linreg import LinearRegressionReport
from .classification.mlclass import MLClassificationReport


